import os
import json
import random
import string
from moviepy.editor import ImageClip, AudioFileClip, CompositeVideoClip, concatenate_audioclips
from PIL import Image, ImageDraw, ImageFont

# Shortcut variables
VIDEO_DURATION = 15 # Video duration in seconds
AUDIO_VOLUME = 0.5  # Audio volume (0.0 to 1.0)

# Function to generate a random filename
def generate_random_filename(length=10):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length)) + ".mp4"

# Function to clean up temporary files in tempfiles folder
def clean_temp_files(folder):
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f"Failed to delete {file_path}. Reason: {e}")

# Ensure tempfiles and finalvideo directories exist and clean them up
tempfiles_folder = 'tempfiles'
finalvideo_folder = 'finalvideo'
os.makedirs(tempfiles_folder, exist_ok=True)
os.makedirs(finalvideo_folder, exist_ok=True)
clean_temp_files(tempfiles_folder)

# Load quotes from JSON file
with open('quotes.json', 'r') as file:
    quotes = json.load(file)

# Select a random quote
quote = random.choice(quotes)
quote_text = f'"{quote["quote"]}"\n\n- {quote["author"]}'

# Wrap text to include only three words per line
def wrap_text(text, words_per_line):
    words = text.split()
    wrapped_lines = [' '.join(words[i:i+words_per_line]) for i in range(0, len(words), words_per_line)]
    return '\n'.join(wrapped_lines)

wrapped_text = wrap_text(quote["quote"], 3)
quote_text = f'{wrapped_text}\n\n- {quote["author"]}'

# Create an image with the desired ratio (YouTube Shorts: 9:16)
image_width = 1080
image_height = 1920

# Load the background image
background = Image.open("mainimage.webp").convert("RGB")
background = background.resize((image_width, image_height))

# Initialize ImageDraw on the background image
draw = ImageDraw.Draw(background)

# Load the font
try:
    font_path = "arial.ttf"  # Path to the font file
    font_size = 50  # Increased font size
    font = ImageFont.truetype(font_path, font_size)
except OSError:
    # Fallback to a default PIL font if the specified font is not found
    font = ImageFont.load_default()

# Calculate text size and position using multiline_textbbox
text_bbox = draw.multiline_textbbox((0, 0), quote_text, font=font)
text_width = text_bbox[2] - text_bbox[0]
text_height = text_bbox[3] - text_bbox[1]
x = (image_width - text_width) / 2
y = (image_height - text_height) / 2

# Add black outline to text
outline_color = "black"
outline_width = 2
draw.multiline_text((x, y), quote_text, fill=(255, 255, 255), font=font, align="center", stroke_width=outline_width, stroke_fill=outline_color)

# Save the combined image temporarily
combined_image_path = os.path.join(tempfiles_folder, 'combined_image.png')
background.save(combined_image_path)

# Create a video clip from the combined image
background_clip = ImageClip(combined_image_path).set_duration(VIDEO_DURATION)

# Load and loop the music manually
audio_clip = AudioFileClip("music.mp3").volumex(AUDIO_VOLUME)
audio_duration = audio_clip.duration

# Repeat the audio clip to match the video duration
num_loops = int(VIDEO_DURATION / audio_duration) + 1
looped_audio = concatenate_audioclips([audio_clip] * num_loops).subclip(0, VIDEO_DURATION)

# Add the audio to the video
final_clip = background_clip.set_audio(looped_audio)

# Generate random output filename
output_filename = generate_random_filename()
output_path = os.path.join(finalvideo_folder, output_filename)

# Export the final video
final_clip.write_videofile(output_path, fps=24)

# Clean up temporary files
clean_temp_files(tempfiles_folder)

print(f"Video created: {output_path}")
